# SuperFastPython.com
# report the id for the current thread
from threading import get_ident
# get the id for the current thread
identifier = get_ident()
# report the thread id
print(identifier)
